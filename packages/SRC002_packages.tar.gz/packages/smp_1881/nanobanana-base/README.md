# Nanobanana Base｜StudioJinsei

**作成日：2025/12/20**

StudioJinseiのすべてのビジュアル制作で共通して使用する基本セットです。
ロゴ、サイト、LINE、SNS等、どのビジュアルを作る時もこのディレクトリを参照してください。

---

## 🚀 使い方（シンプルな流れ）

### 新しいプロジェクトを始める場合

1. **このディレクトリ（nanobanana-base）を渡す**
2. **プロジェクト概要を伝える**
3. AIが自動でセットアップ

### プロジェクト中に修正が必要になった場合

| 担当 | 作業 |
|-----|------|
| AI | プロジェクト内のnanobanana-baseを編集 + CHANGELOG.md更新 |
| あなた | 確認 → 手動で大元に差し替え → コミット |

**手動差し替えコマンド（あなたが実行）:**
```bash
# 大元を差し替え
rm -rf ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/nanobanana-base
cp -r ~/Desktop/StudioJinsei/[プロジェクト]/nanobanana-base ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/

# 大元でコミット
cd ~/Desktop/StudioJinsei/opening-preparation
git add manuals/nanobanana/nanobanana-base/
git commit -m "feat(nanobanana): v[日付] - [変更内容]"
git push
```

---

## 📁 このディレクトリについて

### 目的
- StudioJinseiのブランドデザインを統一
- Nanobananaでの画像生成を効率化
- プロンプト作成の土台を提供

### 使い方
1. ビジュアルを作りたい時、このディレクトリを開く
2. 用途に応じて必要なファイルを参照
3. プロンプトを作成して、Nanobananaで生成

---

## 📂 ファイル構成

```
nanobanana-base/                # StudioJinsei用ベース（このディレクトリ）
├── README.md                   # このファイル
├── nanobanana.py               # 画像生成ツール（動作確認済み）★
├── brand-foundation.md         # ブランド基盤 ★必読
├── kotone-character.md         # コトネちゃん設定 ★
├── setup-guide.md              # セットアップガイド
├── usage-guide.md              # 使い方ガイド
├── pricing-guide.md            # 料金ガイド
├── tips.md                     # Tips・コツ
├── SKILL.md                    # Claudeスキル定義
└── images/                     # 参照画像ディレクトリ
```

**注意：** プロジェクト固有のファイル（`logo_prompt_dalle3.txt`、`CHANGELOG.md`、`VERSION_CONTROL.md`）はプロジェクトルートに配置してください。詳細は「プロジェクトで作成されるディレクトリ」セクションを参照してください。

★ = すべてのビジュアル制作で必ず参照するファイル

**プロジェクトで作成されるディレクトリ:**
```
your-project/
├── nanobanana-base/            # このディレクトリをコピー
├── logo_prompt.txt             # 用途別プロンプト
└── images/
    └── output/                 # 生成画像の保存先（自動作成）
        └── logo_20251221_154115.png
```

---

## 🎯 各ファイルの役割

詳細は各ファイルを参照してください：

- **[nanobanana.py](./nanobanana.py)** ★ツール - 画像生成自動化ツール（Imagen 4.0対応・動作確認済み）
- **[brand-foundation.md](./brand-foundation.md)** ★必読 - ブランド共通デザイン土台、共通プロンプト基盤
- **[kotone-character.md](./kotone-character.md)** ★コトネちゃん制作時 - コトネちゃん設定、プロンプト
- **[setup-guide.md](./setup-guide.md)** - セットアップ方法、環境変数設定、変更管理手順
- **[usage-guide.md](./usage-guide.md)** - 画像生成ガイド、プロンプト作成方法、二段階ワークフロー
- **[pricing-guide.md](./pricing-guide.md)** - 料金目安、API代金確認方法、コスト管理
- **[tips.md](./tips.md)** - プロンプト作成のコツ、チェックリスト、品質管理
- **[SKILL.md](./SKILL.md)** - Claudeスキル定義、AI向け自動セットアップ手順

**プロジェクト固有ファイル（プロジェクトルートに配置）:**
- `logo_prompt_dalle3.txt` - DALL-E 3用シンプルプロンプト（無料プロトタイプ用）
- `CHANGELOG.md` - 変更履歴、改善記録、学び（AI読解改善含む）
- `VERSION_CONTROL.md` - バージョン管理ファイル

---

## 🚀 クイックスタート

### Step 1: セットアップ（初回のみ）

詳細は [setup-guide.md](./setup-guide.md) を参照してください。

**簡単な手順：**
1. 環境変数設定（`GOOGLE_API_KEY`）
2. Claudeスキルにnanobananaを設定（推奨）
3. Pythonパッケージをインストール

### Step 2: プロンプト作成

**重要：** すべてのプロンプトは `@docs/manuals/nanobanana/nanobanana-base` を参照し、必要に応じて追加プロンプトを作成します。

詳細は [usage-guide.md](./usage-guide.md) を参照してください。

**ポイント：**
- ベースプロンプトは [brand-foundation.md](./brand-foundation.md) から自動読み込み
- 追加プロンプトファイル名は用途がわかる名前に（例：`logo_prompt.txt`）

### Step 3: 画像生成

詳細は [SKILL.md](./SKILL.md) を参照してください。

---

## 💡 使用パターン

**重要：** すべてのパターンで、まず `@docs/manuals/nanobanana/nanobanana-base` を参照してください。必要に応じて追加プロンプトファイルを作成します。

詳細は [usage-guide.md](./usage-guide.md) を参照してください。

**基本パターン：**
- **ロゴを作る** - [brand-foundation.md](./brand-foundation.md) を参照 → `logo_prompt.txt` を作成
- **コトネちゃんを作る** - [brand-foundation.md](./brand-foundation.md) + [kotone-character.md](./kotone-character.md) を参照 → `kotone_prompt.txt` を作成
- **サイトビジュアルを作る** - [brand-foundation.md](./brand-foundation.md) を参照 → `site_prompt.txt` を作成

**プロンプトファイル名の例：**
- `logo_prompt.txt` - ロゴ制作用
- `kotone_prompt.txt` - コトネちゃん制作用
- `site_prompt.txt` - サイトビジュアル用
- `banner_prompt.txt` - バナー制作用

---

## 📋 チェックリスト・Tips・料金

詳細は以下のファイルを参照してください：

- [チェックリスト・Tips](./tips.md) - チェックリスト、プロンプト作成のコツ、コスト最適化、品質管理
- [料金ガイド](./pricing-guide.md) - 料金目安、API代金の確認方法、コスト管理

---

## 🔗 関連資料

### このディレクトリ内
- [ブランド共通デザイン土台](./brand-foundation.md) ★必読
- [コトネちゃん設定](./kotone-character.md) ★コトネちゃん制作時
- [セットアップガイド](./setup-guide.md) - 初回セットアップ時
- [使い方ガイド](./usage-guide.md) - 画像生成時
- [料金ガイド](./pricing-guide.md) - 料金・コスト管理
- [Tips・チェックリスト](./tips.md) - プロンプト作成のコツ、品質管理
- [SKILL.md](./SKILL.md) - Claudeスキル定義

### 外部資料
- [会社コンセプト](../../opening-preparation/strategy/company-concept.md)
- [デザインコンセプト](../../opening-preparation/strategy/design-concept.md)
- [brand-visualizer skill](../../.claude/skills/brand-visualizer/SKILL.md)

---

## 📝 変更管理の流れ（プロジェクト → 大元）

### 役割分担

| 担当 | 作業 |
|-----|------|
| **AI** | プロジェクト内のnanobanana-baseを編集 + CHANGELOG.md更新 |
| **あなた** | 確認 → 手動で大元に差し替え → コミット |

### Step 1: AIがプロジェクト内で編集

1. プロジェクトで nanobanana-base を改善
2. CHANGELOG.md に変更内容を記録

### Step 2: あなたが手動で大元に差し替え

```bash
# 大元を差し替え
rm -rf ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/nanobanana-base
cp -r ~/Desktop/StudioJinsei/[プロジェクト]/nanobanana-base ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/

# 大元でコミット
cd ~/Desktop/StudioJinsei/opening-preparation
git add manuals/nanobanana/nanobanana-base/
git commit -m "feat(nanobanana): v[日付] - [変更内容]"
git push
```

**例（brand/logoプロジェクトの場合）:**
```bash
rm -rf ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/nanobanana-base
cp -r ~/Desktop/StudioJinsei/brand/logo/nanobanana-base ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/
cd ~/Desktop/StudioJinsei/opening-preparation
git add manuals/nanobanana/nanobanana-base/
git commit -m "feat(nanobanana): v20251221 - ロゴ生成改善"
git push
```

### 📦 大元リポジトリ情報

**リポジトリURL：** `https://github.com/StudioJinsei/opening-preparation`
**nanobanana-baseの場所：** `manuals/nanobanana/nanobanana-base/`

### ⚠️ プロジェクトでnanobanana-baseを取得する方法

**新しいプロジェクトを始める時：**
```bash
# 大元からコピー
cp -r ~/Desktop/StudioJinsei/opening-preparation/manuals/nanobanana/nanobanana-base ~/Desktop/StudioJinsei/[新プロジェクト]/
```

---

**最終更新：2025/12/21**
