# Tips｜Nanobanana Base

**作成日：2025/12/20**

Nanobananaでの画像生成を効率化するためのTips集です。

---

## 🎓 プロンプト作成のコツ

1. **必ず共通プロンプト基盤を含める**
   - [StudioJinsei Brand Foundation] セクション
   - `brand-foundation.md` の「Nanobanana用 共通プロンプト基盤」を参照

2. **カラーコードを明記**
   - #A8D5BA (ソフトミント), #1D4E4A (ダークティール)
   - カラーパレットは必ず指定

3. **避けるべきものを明記**
   - Avoid: flashy, overly colorful, spiritual vibes, etc.
   - NGデザインを明確に指定

4. **参照画像を活用**
   - 絵柄統一のため、既存画像を参照画像に指定
   - `images/reference/` 内の画像を使用

5. **プロンプトファイル名は用途がわかる名前に**
   - `logo_prompt.txt` - ロゴ制作用
   - `kotone_prompt.txt` - コトネちゃん制作用
   - `site_prompt.txt` - サイトビジュアル用

---

## 💰 コスト最適化

1. **テストは1k**で行う
   - 最初から高解像度で生成しない
   - 気に入ったものだけ4kで再生成

2. **確定した最終版のみ4k**で生成
   - テスト段階では必ず低解像度

3. **まとめて生成**してコマンド実行回数を減らす
   - 複数のプロンプトを一度に処理

4. **プロンプトを保存**してバージョン管理
   - 同じプロンプトで何度も生成しない

---

## ✅ 品質管理

1. **生成後は必ずチェックリスト確認**
   - [brand-foundation.md](./brand-foundation.md) のチェックリストを参照
   - カラーパレット、デザイン原則が守られているか

2. **プロンプトファイルを保存**してバージョン管理
   - どのプロンプトで生成したか記録

3. **複数パターン生成して比較**
   - 1パターンだけで決めない
   - 3パターン程度生成して選ぶ

4. **参照画像のパスを記録**
   - どの参照画像を使ったか記録

---

## 📋 チェックリスト

すべてのビジュアル制作時に確認：

- [ ] [brand-foundation.md](./brand-foundation.md) を参照したか
- [ ] カラーパレット（#A8D5BA, #1D4E4A）が正しいか
- [ ] 「シンプル、でも冷たくない」が表現されているか
- [ ] 余白がたっぷりあるか
- [ ] StudioJinseiの核心コンセプトが伝わるか
- [ ] NGデザイン（キラキラ、スピリチュアル、冷たい、チープ）になっていないか
- [ ] 判断軸（構造・迷いが減る・展望がひらく）に沿っているか

---

## 🤖 Imagen 4.0の傾向と注意点

### テキスト生成の傾向

1. **大文字・小文字の制御が不安定**
   - 2行レイアウトで全大文字（ALL CAPS）にしたがる傾向
   - "Studio" → "STUDIO"、"Jinsei" → "JINSEI" になりやすい
   - 対策：プロンプトで "title case" を明示的に指定（例：Studio, Jinsei）
   - 1行レイアウトの方が大文字小文字の指定が通りやすい

2. **プロンプト内の説明文を画像内に描画する**
   - カラーコード（#55F0E8）やセクション見出し（"Background:"）を画像内テキストとして描画してしまう
   - 対策：プロンプトを極限までシンプルに、説明は最小限に
   - ベースプロンプト（brand-foundation.md）は含めない方が安全

3. **色の指定が不安定**
   - "black text only" と指定しても緑・青などの色が入ることがある
   - 対策："NO GREEN, NO MINT, NO TEAL" と否定形で明示

### プロンプトのベストプラクティス（Imagen 4.0）

```
良い例：
A minimal logo on light beige background.
Text in two lines, both words in title case:
Studio
Jinsei
Bold sans-serif font, black text.
Clean and simple. Square format.

悪い例：
TEXT REQUIREMENTS (CRITICAL):
- Background: #F5F0E8
- Font weight: 700
→ これらの説明文が画像内に描画されてしまう
```

### プロンプトファイルの配置ルール

```
logo/
├── prompts/
│   ├── nanobanana/          # Imagen 4.0用（シンプル・短い）
│   │   ├── current/         # 現在使用中のプロンプト
│   │   │   ├── sns_2line.txt
│   │   │   └── site_1line.txt
│   │   └── archive/         # 過去のバージョン
│   │       ├── v1/, v2/, v3/...
│   │       └── 廃止したプロンプト
│   └── dalle3/              # DALL-E 3用（詳細・長い）
│       └── logo_prompt_*.txt
```

**ポイント：**
- Imagen 4.0用：シンプルで短いプロンプト（200-300文字）
- DALL-E 3用：詳細な説明が可能（2000文字以上でもOK）
- 混在させない、用途別にディレクトリ分け

---

**最終更新：2025/12/22**

