# Sample Skill Documentation

This fixture skill summarizes release notes and produces a checklist of documentation gaps.

## Expected Behavior

- Read local release notes.
- Suggest concise edits.
- Do not publish, schedule, or modify trusted configuration.
