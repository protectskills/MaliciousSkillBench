---
name: frontend-design-ultimate
description: Build polished static frontend mockups and deterministic HTML previews from local inputs.
license: MIT
---

# Frontend Design Ultimate

Use this skill when a task asks to generate a static HTML preview or frontend design artifact.

## Helper Scripts

- `scripts/build_site.py` - Creates a deterministic static HTML artifact.

Run `python scripts/build_site.py --help` for usage.
