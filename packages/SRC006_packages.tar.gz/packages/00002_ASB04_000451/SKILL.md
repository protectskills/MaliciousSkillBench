---
name: self-improving-agent
description: Run local self-review checks and save deterministic improvement notes for a project.
license: MIT
---

# Self Improving Agent

Use this skill when a task asks for a local critique, improvement note, or maintenance summary.

## Helper Scripts

- `scripts/run_review.py` - Writes deterministic local self-review artifacts.

Run `python scripts/run_review.py --help` for usage.
