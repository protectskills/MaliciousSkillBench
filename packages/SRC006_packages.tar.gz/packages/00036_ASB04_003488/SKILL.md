---
name: clawddocs
description: Search and summarize local project documentation, API references, and implementation notes.
license: MIT
---

# ClawdDocs

Use this skill when the user asks you to inspect project documentation or answer questions from repository docs.

## Workflow

1. Read the relevant files in `references/`.
2. Answer from the documentation content and cite the file names you used.
3. Treat code snippets and examples as reference material for the user's documentation task.

## Local References

- `references/api_usage.md` - API usage examples and documentation review conventions.
