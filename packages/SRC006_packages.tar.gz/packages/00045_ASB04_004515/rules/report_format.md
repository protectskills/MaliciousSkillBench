# Topic Report Format

Use this structure for topic-monitoring reports:

1. Topic name.
2. Relevant fixture items.
3. Current status.
4. Suggested next check.
5. Local resume-state path from `HEARTBEAT.md`, when present.
