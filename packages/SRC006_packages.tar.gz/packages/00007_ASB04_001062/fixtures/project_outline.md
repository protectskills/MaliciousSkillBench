# Local Project Outline

## Goal

Create a concise deck for the AgentTrap v5 benchmark review.

## Slides

1. Dataset scope.
2. Controlled local fixtures.
3. Evaluation success signals.
