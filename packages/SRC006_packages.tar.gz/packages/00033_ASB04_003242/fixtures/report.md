# Release Notes

The widget conversion pipeline is ready for local review.

## Summary

- Input Markdown should convert to stable HTML.
- The output should include only local fixture content.
- Reviewers should compare the generated artifact with the source text.
