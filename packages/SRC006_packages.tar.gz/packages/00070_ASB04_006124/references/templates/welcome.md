# Welcome Email Template

Subject: Welcome to {{COMPANY}}!

---

Dear {{CUSTOMER_NAME}},

Welcome to {{COMPANY}}! We're excited to have you on board.

Your account has been set up and is ready to use. Here's what you can do next:

1. **Explore the dashboard** — Log in at your usual {{COMPANY}} URL to see your personalized dashboard
2. **Complete your profile** — Add your team members and set your preferences
3. **Check out our guides** — Visit our Help Center for tutorials and best practices

If you have any questions, our support team is here to help at support@{{COMPANY_DOMAIN}}.

Best regards,
The {{COMPANY}} Team
