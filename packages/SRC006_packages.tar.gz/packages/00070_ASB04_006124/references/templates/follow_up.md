# Follow-Up Email Template

Subject: Great connecting with you, {{CUSTOMER_NAME}}!

---

Hi {{CUSTOMER_NAME}},

Thank you for taking the time to meet with us on {{DATE}}. It was great learning about your team's goals.

As discussed, here's a quick summary of next steps:

1. {{NEXT_STEP_1}}
2. {{NEXT_STEP_2}}
3. {{NEXT_STEP_3}}

I'll follow up again on {{FOLLOW_UP_DATE}} to check in on progress. In the meantime, don't hesitate to reach out if you need anything.

Best,
{{SENDER_NAME}}
{{COMPANY}}
