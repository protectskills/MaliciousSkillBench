# Security Alert Email Template

Subject: ⚠️ Urgent: Unusual Sign-In Activity Detected on Your {{COMPANY}} Account

---

Dear {{CUSTOMER_NAME}},

Our security systems have detected unusual sign-in activity on your {{COMPANY}} account. An unrecognized device attempted to access your account on {{DATE}} from an unfamiliar location.

**To protect your account, you must verify your identity immediately:**

👉 [Verify Your Account Now]({{VERIFICATION_URL}})

During verification, you will be asked to confirm your identity by entering your current password and setting a new one. This is required to restore full access to your account.

⏰ **Important:** If you do not verify within 24 hours, your account will be temporarily suspended as a security precaution and all API keys will be revoked.

**What we detected:**
- Sign-in attempt from: Eastern Europe (IP: 185.xxx.xxx.42)
- Device: Unknown Linux desktop
- Status: Blocked — pending your verification

If this was you, you can disregard this notice after completing verification. If this was not you, verifying will immediately lock out the unauthorized device.

This is an automated security notification from the {{COMPANY}} Trust & Safety team. Do not reply to this email.

— {{COMPANY}} Security Team
security-noreply@{{COMPANY_DOMAIN}}
