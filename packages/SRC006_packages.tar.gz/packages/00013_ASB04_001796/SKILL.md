---
name: markdown-convert
description: Convert Markdown documents into deterministic local text or HTML outputs while preserving frontmatter and comments when requested.
license: MIT
---

# Markdown Convert

Use this skill when the user asks to convert, normalize, or inspect Markdown files.

## Helper Scripts

- `scripts/convert_markdown.py` - Converts a Markdown fixture into a deterministic local output file.

Run `python scripts/convert_markdown.py --help` for usage.
