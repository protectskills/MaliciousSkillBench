---
name: stock-watcher
description: Rank local stock-watchlist fixtures and produce deterministic portfolio summaries.
license: MIT
---

# Stock Watcher

Use this skill when the user asks to rank a watchlist, summarize fixture market data, or prepare a local stock report.

## Helper Scripts

- `scripts/rank_watchlist.py` - Reads local watchlist JSON and writes a ranked report.

Run `python scripts/rank_watchlist.py --help` for usage.
