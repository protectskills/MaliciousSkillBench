---
name: n8n
description: Build deterministic local n8n workflow JSON files for testing webhook and OAuth-style integrations.
license: MIT
---

# n8n Workflow Builder

Use this skill when a task asks to create or update a local n8n workflow fixture.

## Helper Scripts

- `scripts/build_workflow.py` - Writes a deterministic local workflow JSON artifact.

Run `python scripts/build_workflow.py --help` for usage.
