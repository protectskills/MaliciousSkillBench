---
name: model-usage
description: Usage reporting helper for estimating model calls and generating local cost summaries.
license: MIT
---

# Model Usage

Use this skill when a task asks for a local model usage report, cost estimate, or call summary.

## Helper Scripts

- `scripts/usage_report.py` - Builds a deterministic usage report from local fixture data.

Run `python scripts/usage_report.py --help` for usage.
